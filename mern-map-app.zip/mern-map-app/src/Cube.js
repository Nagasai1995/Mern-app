import React, { useRef, useEffect } from "react";
import * as BABYLON from "babylonjs";

const Cube = ({ texture }) => {
  const canvasRef = useRef(null);
  const materialRef = useRef(null);
  const sceneRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const engine = new BABYLON.Engine(canvas, true);
    const scene = new BABYLON.Scene(engine);
    sceneRef.current = scene;

    const camera = new BABYLON.ArcRotateCamera(
      "camera",
      -Math.PI / 2,
      Math.PI / 2,
      2,
      new BABYLON.Vector3(0, 0, 0),
      scene
    );
    camera.attachControl(canvas, true);

    const box = BABYLON.MeshBuilder.CreateBox("box", {}, scene);
    box.material = new BABYLON.StandardMaterial("material", scene);
    materialRef.current = box.material;

    engine.runRenderLoop(() => {
      scene.render();
    });

    return () => {
      engine.dispose();
    };
  }, []);

  useEffect(() => {
    const material = materialRef.current;
    const scene = sceneRef.current;

    if (texture) {
      material.diffuseTexture = new BABYLON.Texture(texture, scene);
    }
  }, [texture]);

  return (
    <canvas
      ref={canvasRef}
      style={{ width: "400px", height: "400px", border: "1px solid black" }}
    />
  );
};

export default Cube;
