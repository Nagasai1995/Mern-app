import React, { useState } from "react";
import Map from "./Map";
import Cube from "./Cube";

function App() {
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [texture, setTexture] = useState(null);

  const handleCapture = () => {
    const canvas = document.querySelector(".mapboxgl-canvas");
    const dataURL = canvas.toDataURL("image/png");
    setTexture(dataURL);
  };

  return (
    <div>
      <Map setSelectedRegion={setSelectedRegion} />
      {selectedRegion && (
        <div>
          <p>Selected Region:</p>
          <p>North East: {selectedRegion.getNorthEast().toString()}</p>
          <p>South West: {selectedRegion.getSouthWest().toString()}</p>
          <button onClick={handleCapture}>Capture Image</button>
        </div>
      )}
      {texture && <Cube texture={texture} />}
    </div>
  );
}

export default App;
