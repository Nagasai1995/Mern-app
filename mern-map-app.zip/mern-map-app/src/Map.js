import React, { useState, useEffect } from "react";
import { Loader } from "@googlemaps/js-api-loader";
import * as BABYLON from 'babylonjs';
import Cube from "./Cube";

const Map = ({ scene }) => {
  const [map, setMap] = useState(null);
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [texture, setTexture] = useState(null);

  useEffect(() => {
    const loader = new Loader({
      apiKey: "AIzaSyAraW-5IVcdLdGbS93rhbQCvl1L81uvSBg",
      version: "weekly",
    });

    loader.load().then((google) => {
      const mapInstance = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 37.7749, lng: -122.4194 },
        zoom: 8,
      });

      setMap(mapInstance);

      const listener = mapInstance.addListener("bounds_changed", () => {
        setSelectedRegion(mapInstance.getBounds());
      });

      return () => google.maps.event.removeListener(listener);
    });
  }, []);

  const captureImage = () => {
    const image = new Image();
    const canvas = document.createElement("canvas");

    canvas.width = map.getDiv().offsetWidth;
    canvas.height = map.getDiv().offsetHeight;

    const ctx = canvas.getContext("2d");

    ctx.drawImage(map.getDiv(), 0, 0);

    image.src = canvas.toDataURL();

    setTexture(new BABYLON.Texture(image.src, scene));
  };

  return (
    <div>
      <div id="map" style={{ width: "100%", height: "500px" }}></div>
      {selectedRegion && (
        <div>
          <p>Selected Region:</p>
          <p>North East: {selectedRegion.getNorthEast().toString()}</p>
          <p>South West: {selectedRegion.getSouthWest().toString()}</p>
          <button onClick={captureImage}>Capture Image</button>
        </div>
      )}
      {texture && <Cube texture={texture} />}
    </div>
  );
};

export default Map;
